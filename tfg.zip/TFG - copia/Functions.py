import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
import folium
import mpimg
from matplotlib.animation import FuncAnimation
# from pymaps import Map, PyMap, Icon
from geopy.geocoders import Nominatim
import animatplot
import matplotlib.animation as an
import matplotlib.animation as animation
from shapely import geometry
from math import radians, cos, sin, asin, sqrt
from pyproj import Transformer
import shapely.geometry as sgeom
from functools import partial
import pyproj
from shapely.ops import transform
from shapely.geometry import Point
def compute_distance (x, y):
    i=0
    distance=[]
    while (i + 1) < len(x):
        rad = math.pi / 180
        dlat = x[i + 1] - x[i]
        dlon = y[i + 1] - y[i]
        R = 6372.795477598
        a = (math.sin(rad * dlat / 2)) ** 2 + math.cos(rad * x[i]) * math.cos(
            rad * x[i + 1]) * (math.sin(rad * dlon / 2)) ** 2
        d = 2 * R * math.asin(math.sqrt(a))
        distance.append(d)
        # time.append((d/ServiceRoadsVelocity)*3600)
        i = i + 1
    return distance
def compute_distance_time (x, y, velocity):
    i=0
    distance=[]
    time=[]
    time.append(1)
    while (i + 1) < len(x):
        rad = math.pi / 180
        dlat = x[i + 1] - x[i]
        dlon = y[i + 1] - y[i]
        R = 6372.795477598
        a = (math.sin(rad * dlat / 2)) ** 2 + math.cos(rad * x[i]) * math.cos(
            rad * x[i + 1]) * (math.sin(rad * dlon / 2)) ** 2
        d = 2 * R * math.asin(math.sqrt(a))
        distance.append(d)
        time.append(time[i]+(d / velocity) * 3600)
        i = i + 1
    return distance, time
def priority(type):
    priority = ''
    if (type=='MediumAirplane'):
        priority='High'
    if (type== 'Fuel'):
        priority='Low'
    if (type== 'BaggageTractor'):
        priority='Low'
    if (type=='SmallAirplane'):
        priority='Low'
    return priority

def haversine(lon1, lat1, lon2, lat2):
    """
    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees)
    """
    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371 # Radius of earth in kilometers. Use 3956 for miles
    return c * r

def stopvehicle (x1,y1,x2,y2,timegraph,radius, conflictpositions1x, conflictpositions1y, conflictpositions2x, conflictpositions2y, priority, priority2):
    i=0
    j=0
    m=0
    k=0
    n=0
    u=0
    h=0
    xfinal1=[]
    yfinal1=[]
    xfinal2=[]
    yfinal2=[]
    time=[]
    timeB=[]
    timegraphic=[]
    timegraphicf=[]
    circlex = []
    circley = []
    xA=[]
    yA=[]
    xB=[]
    yB=[]
    trajectoryAx=[]
    trajectoryAy=[]
    trajectoryBx=[]
    trajectoryBy=[]
    encontrado=False
    while i< len(x1) or m<len(y1):
        if i< len(x1) and m<len(y1):
            xfinal1.append(x1[i])
            yfinal1.append(y1[i])
            xfinal2.append(x2[m])
            yfinal2.append(y2[m])
            if not encontrado:
                timegraphic.append(timegraph[u])
            if encontrado:
                xB.append(x2[m])
                yB.append(y2[m])
            if (x1[i]==conflictpositions1x[j] and y1[i]==conflictpositions1y[j]) and (x2[m]==conflictpositions2x[j] and y2[m]==conflictpositions2y[j]):
                encontrado = True
                if priority2 =='High':
                    m=m+1
                    k=k+1
                    u=u+1
                    circlex.append(x2[m])
                    circley.append(y2[m])
                    time.append(timegraph[k])
                    xA.append(x1[k])
                    yA.append(y1[k])
                    timegraphic.append(timegraph[u])
                    x = conflictpositions1x[n]
                    y = conflictpositions1y[n]

                    xfinal1.append(x)
                    yfinal1.append(y)
                    xfinal2.append(x2[m])
                    yfinal2.append(y2[m])
                    center_point = [{'lat': xfinal2[-1], 'lng': yfinal2[-1]}]
                    test_point = [{'lat':x, 'lng': y}]

                    lat1 = center_point[0]['lat']
                    lon1 = center_point[0]['lng']
                    lat2 = test_point[0]['lat']
                    lon2 = test_point[0]['lng']
                    radius = radius  # in kilometer

                    a = haversine(lon1, lat1, lon2, lat2)
                    if a <= radius:
                        while a<=radius:
                            m = m + 1
                            k=k+1
                            u=u+1
                            xfinal1.append(x)
                            yfinal1.append(y)
                            xfinal2.append(x2[m])
                            yfinal2.append(y2[m])
                            circlex.append(x2[m])
                            circley.append(y2[m])
                            time.append(timegraph[k])
                            xA.append(x1[k])
                            yA.append(y1[k])
                            timegraphic.append(timegraph[u])
                            center_point = [{'lat': xfinal2[-1], 'lng': yfinal2[-1]}]
                            test_point = [{'lat': x, 'lng': y}]

                            lat1 = center_point[0]['lat']
                            lon1 = center_point[0]['lng']
                            lat2 = test_point[0]['lat']
                            lon2 = test_point[0]['lng']
                            radius = radius  # in kilometer

                            a = haversine(lon1, lat1, lon2, lat2)

                        else:
                            h=k
                            while h<len(timegraph):
                                timeB.append(timegraph[h])
                                h=h+1
                            i=i+1
                            k=k+1
                            xfinal1.append(x1[i])
                            yfinal1.append(y1[i])
                            xfinal2.append(x2[m])
                            yfinal2.append(y2[m])
                            timegraphic.append(timegraph[u])
                            trajectoryAx=xfinal1
                            trajectoryAy=yfinal1
                            trajectoryBx=xfinal2
                            trajectoryBy=yfinal2


            else:
                  i=i+1
                  k=k+1
                  m=m+1
                  n=j
                  u=u+1
        if i>=len(x1) and m<len(x2):
            xfinal2.append(x2[m])
            xfinal1.append(x1[-1])
            yfinal2.append(y2[m])
            yfinal1.append(y1[-1])
            m=m+1
        if m>=len(x2) and i<len(x1):
            xfinal1.append(x1[i])
            xfinal2.append(x2[-1])
            yfinal1.append(y1[i])
            yfinal2.append(y2[-1])
            i=i+1
    return xfinal1,xfinal2,yfinal1,yfinal2, time, timeB, timegraphic, circlex, circley, xA, yA, xB, yB

def computetime(timeA,timeB,x1,y1,x2,y2):
    i=1
    j=1
    timegraph=[]
    timegraph.append(1)
    timegraphf=[]
    timegraphf.append(1)
    while i<len(timeA) or j<len(timeB):
        if i<len(timeA) and j<len(timeB):
            b=timeA[i]
            c=timeB[j]
            if b<c:
                timegraph.append(b)
                i=i+1
            if c<b:
                timegraph.append(c)
                j=j+1
        if i >= len(timeA) and j < len(timeB):
            timegraph.append(timeB[j])
            j = j + 1
        if j >= len(timeB) and i <len(timeA):
            timegraph.append(timeA[i])
            i = i + 1

    i = 0
    j = 0
    while (i + 1) < len(timegraph):
        timegraphf.append(timegraph[i + 1] - timegraph[i])
        i = i + 1

    trackx1 = []
    tracky1 = []
    trackx2 = []
    tracky2 = []
    i = 0
    k = 0
    j = 0
    l = 0
    # radiusfinal1=[]
    while k < len(timegraph) or l < len(timegraph):
        if k < len(timegraph):
            if i < len(timeA):
                if timegraph[k] == timeA[i]:
                    trackx1.append(x1[i])
                    tracky1.append(y1[i])
                    k = k + 1
                    i = i + 1
                else:
                    if i>0:
                        trackx1.append(x1[i - 1])

                        tracky1.append(y1[i - 1])
                        k = k + 1
                    if i==0:
                        trackx1.append(x1[0])
                        tracky1.append(y1[0])
                        k=k+1
        if l < len(timegraph):
            if j < len(timeB):
                if timegraph[l] == timeB[j]:
                    trackx2.append(x2[j])
                    tracky2.append(y2[j])
                    l = l + 1
                    j = j + 1
                else:
                    if j>0:
                        trackx2.append(x2[j - 1])
                    #              radiusfinal1.append(radius[j - 1])
                        tracky2.append(y2[j - 1])
                        l = l + 1
                    if j==0:
                        trackx2.append(x2[0])
                        tracky2.append(y2[0])
                        l=l+1
        if i >= len(timeA) and k < len(timegraph):
            trackx1.append(x1[i - 1])
            tracky1.append(y1[i - 1])
            k = k + 1
        if j >= len(timeB) and l < len(timegraph):
            #     radiusfinal1.append(radius[j - 1])
            trackx2.append(x2[j - 1])
            tracky2.append(y2[j - 1])
            l = l + 1
    return timegraphf, trackx1,tracky1, trackx2, tracky2
def time_track(time,time2, x, y, x2,y2):
    timegraph = []
    i = 1
    j = 1
    timegraph.append(1)
    b = 0
    c = 0
    while i < len(time) or j < len(time2):
        if i < len(time) and j < len(time2):
            b = time[i]
            c = time2[j]
            if b < c:
                timegraph.append(b)
                i = i + 1
            if c < b:
                timegraph.append(c)
                j = j + 1
        if i >= len(time) and j < len(time2):
            timegraph.append(time2[j])
            j = j + 1
        if j >= len(time2) and i < len(time):
            timegraph.append(time[i])
            i = i + 1

    trackx1 = []
    tracky1 = []
    trackx2 = []
    tracky2 = []
    i = 0
    k = 0
    j = 0
    l = 0
    # radiusfinal1=[]
    while k < len(timegraph) or l < len(timegraph):
        if k < len(timegraph):
            if i < len(time):
                if timegraph[k] == time[i]:
                    trackx1.append(x[i])
                    tracky1.append(y[i])
                    k = k + 1
                    i = i + 1
                else:
                    trackx1.append(x[i - 1])

                    tracky1.append(y[i - 1])
                    k = k + 1
        if l < len(timegraph):
            if j < len(time2):
                if timegraph[l] == time2[j]:
                    trackx2.append(x2[j])
                    #               radiusfinal1.append(radius[j])
                    tracky2.append(y2[j])
                    l = l + 1
                    j = j + 1
                else:
                    trackx2.append(x2[j - 1])
                    #              radiusfinal1.append(radius[j - 1])
                    tracky2.append(y2[j - 1])
                    l = l + 1
        if i >= len(time) and k < len(timegraph):
            trackx1.append(x[i - 1])
            tracky1.append(y[i - 1])
            k = k + 1
        if j >= len(time2) and l < len(timegraph):
            #     radiusfinal1.append(radius[j - 1])
            trackx2.append(x2[j - 1])
            tracky2.append(y2[j - 1])
            l = l + 1
    return timegraph, trackx1,tracky1, trackx2,tracky2

def time_graphfinal(time,x1,y1,x2,y2,time2,x3,y3,x4,y4,time3,x5,y5,x6,y6):
    timegraph = []
    i = 1
    j = 1
    k = 1
    timegraph.append(1)
    b = 0
    c = 0
    d=0
    while i < len(time) or j < len(time2) or k < len(time3):
        if i < len(time) and j < len(time2) and k<len(time3):
            b = time[i]
            c = time2[j]
            d=time3[k]
            if (b < c) and (b<d):
                timegraph.append(b)
                i = i + 1
            if (c < b) and (c<d):
                timegraph.append(c)
                j = j + 1
            if (d<b) and (d<c):
                timegraph.append(d)
                k=k+1


        if i >= len(time) and j < len(time2) and k<len(time3):
            c = time2[j]
            d = time3[k]
            if (c<d):
                timegraph.append(c)
                j = j + 1
            if (d<c):
                timegraph.append(d)
                k=k+1

        if j >= len(time2) and i < len(time) and k<len(time3):
            b=time[i]
            d = time3[k]

            if (b < d):
                timegraph.append(b)
                j = j + 1
            if (d < b):
                timegraph.append(d)
                k = k + 1
        if k >= len(time3) and i < len(time) and j < len(time2):
            b = time[i]
            c = time2[j]
            if (b < c):
                timegraph.append(b)
                j = j + 1
            if (c < b):
                timegraph.append(c)
                k = k + 1
        if i < len(time) and j >= len(time2) and k >= len(time3):
            b = time[i]
            timegraph.append(b)
            i = i + 1
        if i >= len(time) and j >= len(time2) and k<len(time3):
            d = time3[k]
            timegraph.append(d)
            k=k+1
        if i < len(time) and j >= len(time2) and k >= len(time3):
            b = time[i]
            timegraph.append(b)
            i = i + 1
        if i >= len(time) and j < len(time2) and k >= len(time3):
            c = time2[j]
            timegraph.append(c)
            j = j + 1
    timegraphf = []
    timegraphf.append(timegraph[0])
    i = 0
    j = 0
    while (i + 1) < len(timegraph):
        timegraphf.append(timegraph[i + 1] - timegraph[i])
        i = i + 1

    trackx1 = []
    trackx1.append(x1[0])
    tracky1 = []
    tracky1.append(y1[0])
    trackx2 = []
    trackx2.append(x2[0])
    tracky2 = []
    tracky2.append(y2[0])
    trackx3 = []
    trackx3.append(x3[0])
    tracky3 = []
    tracky3.append(y3[0])
    trackx4 = []
    trackx4.append(x4[0])
    tracky4 = []
    tracky4.append(y4[0])
    trackx5 = []
    trackx5.append(x5[0])
    tracky5 = []
    tracky5.append(y5[0])
    trackx6 = []
    trackx6.append(x6[0])
    tracky6 = []
    tracky6.append(y6[0])

    i = 1
    v = 1
    j = 1
    l = 1
    k=1
    # radiusfinal1=[]
    while v < len(timegraph):
        if v < len(timegraph):
            if i < len(time) and j<len(time2) and k<len(time3):
                if timegraph[v] == time[i]:
                    trackx1.append(x1[i])
                    tracky1.append(y1[i])
                    trackx2.append(x2[i])
                    tracky2.append(y2[i])
                    i = i + 1
                else:
                    trackx1.append(x1[i - 1])
                    tracky1.append(y1[i - 1])
                    trackx2.append(x2[i-1])
                    tracky2.append(y2[i-1])
                if timegraph[v]==time2[j]:
                    trackx3.append(x3[j])
                    tracky3.append(y3[j])
                    trackx4.append(x4[j])
                    tracky4.append(y4[j])
                    j=j+1
                else:
                    trackx3.append(x3[j-1])
                    tracky3.append(y3[j-1])
                    trackx4.append(x4[j-1])
                    tracky4.append(y4[j-1])

                if timegraph[v]==time3[k]:
                    trackx5.append(x5[k])
                    tracky5.append(y5[k])
                    trackx6.append(x6[k])
                    tracky6.append(y6[k])
                    k=k+1
                else:
                    trackx5.append(x5[k-1])
                    tracky5.append(y5[k-1])
                    trackx6.append(x6[k-1])
                    tracky6.append(y6[k-1])
                v = v + 1
            if i >= len(time) and v < len(timegraph):
                if j<len(time2) and k<len(time3):
                    trackx1.append(x1[i - 1])
                    tracky1.append(y1[i - 1])
                    trackx2.append(x2[i - 1])
                    tracky2.append(y2[i - 1])
                    if timegraph[v]==time2[j]:
                        trackx3.append(x3[j])
                        tracky3.append(y3[j])
                        trackx4.append(x4[j])
                        tracky4.append(y4[j])
                        trackx5.append(x5[k-1])
                        tracky5.append(y5[k-1])
                        trackx6.append(x6[k-1])
                        tracky6.append(y6[k-1])
                        j = j + 1
                    else:
                        trackx3.append(x3[j-1])
                        tracky3.append(y3[j-1])
                        trackx4.append(x4[j-1])
                        tracky4.append(y4[j-1])
                        trackx5.append(x5[k])
                        tracky5.append(y5[k])
                        trackx6.append(x6[k])
                        tracky6.append(y6[k])
                        k = k + 1
                    v = v + 1
            if j >= len(time2) and v < len(timegraph):
                if i<len(time) and k<len(time3):
                    trackx3.append(x3[j - 1])
                    tracky3.append(y3[j - 1])
                    trackx4.append(x4[j - 1])
                    tracky4.append(y4[j - 1])
                    if timegraph[v]==time[i]:
                        trackx1.append(x1[i])
                        tracky1.append(y1[i])
                        trackx2.append(x2[i])
                        tracky2.append(y2[i])
                        trackx5.append(x5[k - 1])
                        tracky5.append(y5[k - 1])
                        trackx6.append(x6[k - 1])
                        tracky6.append(y6[k - 1])
                        i = i + 1
                    else:
                        trackx5.append(x5[k])
                        tracky5.append(y5[k])
                        trackx6.append(x6[k])
                        tracky6.append(y6[k])
                        trackx1.append(x1[i-1])
                        tracky1.append(y1[i-1])
                        trackx2.append(x2[i-1])
                        tracky2.append(y2[i-1])
                        k=k+1
                    v = v + 1
            if k >= len(time3) and v < len(timegraph):
                if i<len(time) and j<len(time2):
                    trackx5.append(x5[k - 1])
                    tracky5.append(y5[k - 1])
                    trackx6.append(x6[k - 1])
                    tracky6.append(y6[k - 1])
                    if timegraph[v]==time[i]:
                        trackx1.append(x1[i])
                        tracky1.append(y1[i])
                        trackx2.append(x2[i])
                        tracky2.append(y2[i])
                        trackx3.append(x3[j-1])
                        tracky3.append(y3[j-1])
                        i = i + 1
                    else:
                        trackx3.append(x3[j])
                        tracky3.append(y3[j])
                        trackx4.append(x4[j])
                        tracky4.append(y4[j])
                        trackx1.append(x1[i-1])
                        tracky1.append(y1[i-1])
                        trackx2.append(x2[i-1])
                        tracky2.append(y2[i-1])
                        j=j+1
                    v = v + 1
            if j >= len(time2) and k>=len(time3) and v < len(timegraph):
                trackx3.append(x3[j - 1])
                tracky3.append(y3[j - 1])
                trackx4.append(x4[j - 1])
                tracky4.append(y4[j - 1])
                trackx5.append(x5[k-1])
                tracky5.append(y5[k-1])
                trackx6.append(x6[k-1])
                tracky6.append(y6[k-1])
                trackx1.append(x1[i])
                tracky1.append(y1[i])
                trackx2.append(x2[i])
                tracky2.append(x2[i])
                i=i+1
                v=v+1
            if i >= len(time) and k>=len(time3) and v < len(timegraph):
                trackx3.append(x3[j])
                tracky3.append(y3[j])
                trackx4.append(x4[j])
                tracky4.append(y4[j])
                j=j+1
                trackx5.append(x5[k-1])
                tracky5.append(y5[k-1])
                trackx6.append(x6[k-1])
                tracky6.append(y6[k-1])
                trackx1.append(x1[i-1])
                trackx1.append(y1[i-1])
                trackx2.append(x2[i-1])
                tracky2.append(y2[i-1])
                v=v+1
            if i >= len(time) and j>=len(time2) and v < len(timegraph):
                trackx3.append(x3[j-1])
                tracky3.append(y3[j-1])
                trackx4.append(x4[j-1])
                tracky4.append(y4[j-1])
                trackx5.append(x5[k])
                tracky5.append(y5[k])
                trackx6.append(x6[k])
                tracky6.append(y6[k])
                trackx1.append(x1[i-1])
                tracky1.append(y1[i-1])
                trackx2.append(x2[i-1])
                tracky2.append(x2[i-1])
                k=k+1
                v=v+1
    return (timegraphf, trackx1, tracky1, trackx2,tracky2, trackx3, tracky3,trackx4,tracky4,trackx5,tracky5,trackx6,tracky6)
def time_track_radius(time,time2, x, y, x2,y2,radius):
    timegraph = []
    i = 1
    j = 1
    timegraph.append(1)
    b = 0
    c = 0
    while i < len(time) or j < len(time2):
        if i < len(time) and j < len(time2):
            b = time[i]
            c = time2[j]
            if b < c:
                timegraph.append(b)
                i = i + 1
            if c < b:
                timegraph.append(c)
                j = j + 1
        if i >= len(time) and j < len(time2):
            timegraph.append(time2[j])
            j = j + 1
        if j >= len(time2) and i < len(time):
            timegraph.append(time[i])
            i = i + 1

    trackx1 = []
    tracky1 = []
    trackx2 = []
    tracky2 = []
    radiusf=[]
    i = 0
    k = 0
    j = 0
    l = 0
    # radiusfinal1=[]
    while k < len(timegraph) or l < len(timegraph):
        if k < len(timegraph):
            if i < len(time):
                if timegraph[k] == time[i]:
                    trackx1.append(x[i])
                    tracky1.append(y[i])
                    k = k + 1
                    i = i + 1
                else:
                    trackx1.append(x[i - 1])

                    tracky1.append(y[i - 1])
                    k = k + 1
        if l < len(timegraph):
            if j < len(time2):
                if timegraph[l] == time2[j]:
                    trackx2.append(x2[j])
                    radiusf.append(radius[j])
                    #               radiusfinal1.append(radius[j])
                    tracky2.append(y2[j])
                    l = l + 1
                    j = j + 1
                else:
                    trackx2.append(x2[j - 1])
                    radiusf.append(radius[j - 1])
                    tracky2.append(y2[j - 1])
                    l = l + 1
        if i >= len(time) and k < len(timegraph):
            trackx1.append(x[i - 1])
            tracky1.append(y[i - 1])
            k = k + 1
        if j >= len(time2) and l < len(timegraph):
            radiusf.append(radius[j - 1])

            trackx2.append(x2[j - 1])
            tracky2.append(y2[j - 1])
            l = l + 1
    return timegraph, trackx1,tracky1, trackx2,tracky2, radiusf

def radiusdefine(radius4, x5, y5, x6, y6):
    radiusfinal2=[]
    encontrado1=False
    encontrado2=False
    encontrado3=False
    i=0
    while i<len(x5):
        if x5[i]==-6.02165 and y5[i]==43.5604972:
            encontrado1=True

        if x5[i]==-6.025244 and y5[i]==43.561317:
            encontrado2=True
            encontrado1=False
        if x5[i]==-6.03143 and y5[i]==43.56282:
            encontrado3=True
            encontrado2=False
        if encontrado1==True:
            radiusfinal2.append(radius4[1])
        if encontrado2==True:
            radiusfinal2.append(radius4[2])
        if encontrado3==True:
            radiusfinal2.append(radius4[3])
        if encontrado1==False and encontrado2==False and encontrado3==False:
            radiusfinal2.append(radius4[0])
        i=i+1
    return radiusfinal2
def stopvehicleradius(x1,y1,x2,y2,timegraph,radius1, conflictpositions1x, conflictpositions1y, conflictpositions2x, conflictpositions2y, priority, priority2):
    i=0
    j=0
    m=0
    k=0
    n=0
    u=0
    h=0
    xfinal1=[]
    yfinal1=[]
    xfinal2=[]
    yfinal2=[]
    time=[]
    timeB=[]
    timegraphic=[]
    timegraphicf=[]
    circlex = []
    circley = []
    xA=[]
    yA=[]
    xB=[]
    yB=[]
    Radius2=[]

    encontrado=False
    while i< len(x1) or m<len(y1):
        if i< len(x1) and m<len(y1):
            xfinal1.append(x1[i])
            yfinal1.append(y1[i])
            xfinal2.append(x2[m])
            yfinal2.append(y2[m])
            if not encontrado:
                timegraphic.append(timegraph[u])
            if encontrado:
                xB.append(x2[m])
                yB.append(y2[m])
            if (x1[i]==conflictpositions1x[j] and y1[i]==conflictpositions1y[j]) and (x2[m]==conflictpositions2x[j] and y2[m]==conflictpositions2y[j]):
                encontrado = True
                if priority2 =='High':
                    m=m+1
                    k=k+1
                    u=u+1
                    circlex.append(x2[m])
                    circley.append(y2[m])
                    time.append(timegraph[k])
                    xA.append(x1[k])
                    yA.append(y1[k])
                    timegraphic.append(timegraph[u])
                    x = conflictpositions1x[n]
                    y = conflictpositions1y[n]

                    xfinal1.append(x)
                    yfinal1.append(y)
                    xfinal2.append(x2[m])
                    yfinal2.append(y2[m])

                    center_point = [{'lat': xfinal2[-1], 'lng': yfinal2[-1]}]
                    test_point = [{'lat':x, 'lng': y}]

                    lat1 = center_point[0]['lat']
                    lon1 = center_point[0]['lng']
                    lat2 = test_point[0]['lat']
                    lon2 = test_point[0]['lng']
                    radius = radius1[m]  # in kilometer

                    a = haversine(lon1, lat1, lon2, lat2)
                    if a <= radius:
                        while a<=radius:
                            m = m + 1
                            k=k+1
                            u=u+1
                            xfinal1.append(x)
                            yfinal1.append(y)
                            xfinal2.append(x2[m])
                            yfinal2.append(y2[m])
                            circlex.append(x2[m])
                            circley.append(y2[m])
                            time.append(timegraph[k])
                            xA.append(x1[k])
                            yA.append(y1[k])
                            timegraphic.append(timegraph[u])
                            center_point = [{'lat': xfinal2[-1], 'lng': yfinal2[-1]}]
                            test_point = [{'lat': x, 'lng': y}]

                            lat1 = center_point[0]['lat']
                            lon1 = center_point[0]['lng']
                            lat2 = test_point[0]['lat']
                            lon2 = test_point[0]['lng']
                            radius = radius1[m]  # in kilometer

                            a = haversine(lon1, lat1, lon2, lat2)

                        else:
                            h=k
                            while h<len(timegraph):
                                timeB.append(timegraph[h])
                                h=h+1
                            i=i+1
                            k=k+1
                            xfinal1.append(x1[i])
                            yfinal1.append(y1[i])
                            xfinal2.append(x2[m])
                            yfinal2.append(y2[m])
                            timegraphic.append(timegraph[u])
                            trajectoryAx=xfinal1
                            trajectoryAy=yfinal1
                            trajectoryBx=xfinal2
                            trajectoryBy=yfinal2


            else:
                  i=i+1
                  k=k+1
                  m=m+1
                  n=j
                  u=u+1
        if i>=len(x1) and m<len(x2):
            xfinal2.append(x2[m])
            xfinal1.append(x1[-1])
            yfinal2.append(y2[m])
            yfinal1.append(y1[-1])
            m=m+1
        if m>=len(x2) and i<len(x1):
            xfinal1.append(x1[i])
            xfinal2.append(x2[-1])
            yfinal1.append(y1[i])
            yfinal2.append(y2[-1])
            i=i+1
    i=0
    j=0
    while i < len(xfinal2) and j<len(radius1):
        if xfinal2[i] == x2[j] and yfinal2[i]==y2[j]:
            Radius2.append(radius1[j])
            j = j + 1
            i = i + 1
        else:
            Radius2.append(radius1[j])
            i = i + 1
    while j>=len(x2) and i<len(xfinal2):
        Radius2.append(radius1[-1])
        i=i+1
    return xfinal1,xfinal2,yfinal1,yfinal2, time, timeB, timegraphic, circlex, circley, xA, yA, xB, yB, Radius2
