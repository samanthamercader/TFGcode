import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math
from Functions import haversine
from Functions import stopvehicle
from Functions import priority
from Functions import computetime
import folium
import mpimg
from matplotlib.animation import FuncAnimation
# from pymaps import Map, PyMap, Icon
from geopy.geocoders import Nominatim
import animatplot
import matplotlib.animation as an
import matplotlib.animation as animation
from shapely import geometry
from math import radians, cos, sin, asin, sqrt
from pyproj import Transformer
import shapely.geometry as sgeom
from functools import partial
import pyproj
from shapely.ops import transform
from shapely.geometry import Point

def extract_data():
    tree = ET.parse('airsidee.xml')
    root = tree.getroot()
    for child in root:
        print(child.tag, child.attrib)
    SR = []
    lat = []
    long = []

    # extract from xml
    for serviceroads in root.iter('sr'):
        SR.append(serviceroads.attrib)
        for sr in serviceroads.iter('entry'):
            SR.append(sr.attrib)
            for latitude in sr.iter('latitude'):
                lat.append(latitude.attrib)
            for longitude in sr.iter('longitude'):
                long.append(longitude.attrib)
                for decimal_degrees in latitude.iter('decimal_degrees'):
                    # print(decimal_degrees.text)
                    SR.append(float(decimal_degrees.text))
                for decimal_degrees in longitude.iter('decimal_degrees'):
                    #  print(decimal_degrees.text)
                    SR.append(float(decimal_degrees.text))
    # print(SR)
    TW = []
    lat1 = []
    long1 = []

    for taxiways in root.iter('TWY'):
        TW.append(taxiways.attrib)
        for TWY in taxiways.iter('holding_point'):
            TW.append(TWY.attrib)
            for latitude in TWY.iter('latitude'):
                lat1.append(latitude.attrib)
            for longitude in TWY.iter('longitude'):
                long1.append(longitude.attrib)
                for decimal_degrees in latitude.iter('decimal_degrees'):
                    # print(decimal_degrees.text)
                    TW.append(float(decimal_degrees.text))
                for decimal_degrees in longitude.iter('decimal_degrees'):
                    #  print(decimal_degrees.text)
                    TW.append(float(decimal_degrees.text))
    for taxiways in root.iter('TWY'):
        TW.append(taxiways.attrib)
        for TWY in taxiways.iter('crossing_point'):
            TW.append(TWY.attrib)
            for latitude in TWY.iter('latitude'):
                lat1.append(latitude.attrib)
            for longitude in TWY.iter('longitude'):
                long1.append(longitude.attrib)
                for decimal_degrees in latitude.iter('decimal_degrees'):
                    # print(decimal_degrees.text)
                    TW.append(float(decimal_degrees.text))
                for decimal_degrees in longitude.iter('decimal_degrees'):
                    #  print(decimal_degrees.text)
                    TW.append(float(decimal_degrees.text))
    corner2 = []
    for taxiways in root.iter('TWY'):
        corner2.append(taxiways.attrib)
        for TWY in taxiways.iter('corner'):
            corner2.append(TWY.attrib)
            for corner in TWY.iter('entry'):
                corner2.append(corner.attrib)
                for latitude in corner.iter('latitude'):
                    lat1.append(latitude.attrib)
                for longitude in corner.iter('longitude'):
                    long1.append(longitude.attrib)
                    for decimal_degrees in latitude.iter('decimal_degrees'):
                        # print(decimal_degrees.text)
                        corner2.append(float(decimal_degrees.text))
                    for decimal_degrees in longitude.iter('decimal_degrees'):
                        #  print(decimal_degrees.text)
                        corner2.append(float(decimal_degrees.text))
    # print(corner2)
    RWY_exit = []
    lat2 = []
    long2 = []

    for runways in root.iter('rwy_exit'):
        RWY_exit.append(runways.attrib)
        for rwy_exit in runways.iter('entry'):
            RWY_exit.append(rwy_exit.attrib)
            for latitude in rwy_exit.iter('latitude'):
                lat2.append(latitude.attrib)
            for longitude in rwy_exit.iter('longitude'):
                long2.append(longitude.attrib)
                for decimal_degrees in latitude.iter('decimal_degrees'):
                    # print(decimal_degrees.text)
                    RWY_exit.append(float(decimal_degrees.text))
                for decimal_degrees in longitude.iter('decimal_degrees'):
                    #  print(decimal_degrees.text)
                    RWY_exit.append(float(decimal_degrees.text))

    return RWY_exit, TW, SR, corner2
