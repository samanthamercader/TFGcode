import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import math
from Functions import haversine
from Functions import stopvehicle
from Functions import stopvehicleradius
from Functions import priority
from Functions import computetime
from Functions import compute_distance
from Extract_xml import extract_data
from Functions import compute_distance_time
from Functions import time_graphfinal
from Functions import radiusdefine
from Functions import time_track_radius
from Functions import time_track
from Functions import time_track
import mpimg
from matplotlib.animation import FuncAnimation
# from pymaps import Map, PyMap, Icon
from geopy.geocoders import Nominatim
import animatplot
import matplotlib.animation as an
import matplotlib.animation as animation
from shapely import geometry
from math import radians, cos, sin, asin, sqrt
from pyproj import Transformer
import shapely.geometry as sgeom
from functools import partial
import pyproj
from shapely.ops import transform
from shapely.geometry import Point

typevehicle1 = 'Fuel'
typevehicle2 = 'MediumAirplane'
typevehicle4='MediumAirplane'
typevehicle3='SmallAirplane'
typevehicle5="Fuel"
typevehicle6="MediumAirplane"

Radius1=(0.35)
Radius2=[]
Radius3=[]

data=extract_data()
SR=data[2]
RWY_exit=data[0]
corner2=data[3]
TW=data[1]
Fueltrajectory_x = []
Fueltrajectory_y = []
initial_point = {'id': 'TB'}
subinitial = {'id': '1'}
final_point = {'id': 'THR29'}
subfinal = {'id': '3'}

i = 0
j = 1
encontrado = False
# initial trajectory
while (SR[i] != 0 and not encontrado):
    while SR[i] != initial_point:
        if SR[i] != initial_point:
            i = i + 1
    if SR[i] == initial_point:
        encontrado = True
        j = i + 2
while (type(SR[i]) == dict and type(SR[j]) == float):
    Fueltrajectory_x.append(SR[j])
    Fueltrajectory_y.append(SR[j + 1])
    j = j + 3

print(Fueltrajectory_x)
print(Fueltrajectory_y)
i = 0

t = []
vx = 0
Fueltrajectory_x_final = []

distance = compute_distance(Fueltrajectory_x, Fueltrajectory_y)


# print (distance)
Fueltrajectory_y_final = []
i = 0
j = 1
val = 0
# Punts de trajectoria
Fueltrajectory_x_final = []
ServiceRoadsVelocity = 30;

val = 0
val2 = 0
radius=[]
k=0
while (i < len(Fueltrajectory_y)):
    if (j < len(Fueltrajectory_y)):
        if (distance[i] >= 0.08):
            val = (Fueltrajectory_y[j] - Fueltrajectory_y[i]) / 4
            Fueltrajectory_y_final.append(Fueltrajectory_y[i])
            Fueltrajectory_y_final.append(Fueltrajectory_y[i] + val)
            Fueltrajectory_y_final.append(Fueltrajectory_y[i] + 2 * val)
            Fueltrajectory_y_final.append(Fueltrajectory_y[i] + 3 * val)
            val2 = (Fueltrajectory_x[j] - Fueltrajectory_x[i]) / 4
            Fueltrajectory_x_final.append(Fueltrajectory_x[i])
            Fueltrajectory_x_final.append(Fueltrajectory_x[i] + val2)
            Fueltrajectory_x_final.append(Fueltrajectory_x[i] + 2 * val2)
            Fueltrajectory_x_final.append(Fueltrajectory_x[i] + 3 * val2)
        if (distance[i] >= 0.05 and distance[i] < 0.08):
            val = (Fueltrajectory_y[j] - Fueltrajectory_y[i]) / 2
            Fueltrajectory_y_final.append(Fueltrajectory_y[i])
            Fueltrajectory_y_final.append(Fueltrajectory_y[i] + val)
            val2 = (Fueltrajectory_x[j] - Fueltrajectory_x[i]) / 2
            Fueltrajectory_x_final.append(Fueltrajectory_x[i])
            Fueltrajectory_x_final.append(Fueltrajectory_x[i] + val2)
        if (distance[i] < 0.05):
            Fueltrajectory_y_final.append(Fueltrajectory_y[i])
            Fueltrajectory_x_final.append(Fueltrajectory_x[i])
    else:
        Fueltrajectory_y_final.append(Fueltrajectory_y[i])
        Fueltrajectory_x_final.append(Fueltrajectory_x[i])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1

i = 0
while (i + 1) < len(Fueltrajectory_x_final):
    if Fueltrajectory_x_final[i] == Fueltrajectory_x_final[i + 1] and Fueltrajectory_y_final[i] == \
            Fueltrajectory_y_final[i + 1]:
        Fueltrajectory_x_final.pop(i)
        Fueltrajectory_y_final.pop(i)
    i = i + 1
# print (Fueltrajectory_y_final)
# print (Fueltrajectory_x_final)
# Time as a function of distance

i = 0
j=compute_distance_time(Fueltrajectory_x_final, Fueltrajectory_y_final, ServiceRoadsVelocity)
distance2=j[0]
time=j[1]

# trajectory2
Fueltrajectory_x2 = []
Fueltrajectory_y2 = []
initial_point = {'id': 'THR29'}
subinitial = {'id': '1'}
final_point = {'id': 'T'}
subfinal = {'id': 'TB2'}

i = 0
j = 1
encontrado = False
# initial trajectory (THR29-TB2)
# primer tramo (THR29)
while (RWY_exit[i] != 0 and not encontrado):
    while RWY_exit[i] != initial_point:
        if RWY_exit[i] != initial_point:
            i = i + 1
    if RWY_exit[i] == initial_point:
        encontrado = True
        j = i + 2
while (type(RWY_exit[i]) == dict and type(RWY_exit[j]) == float):
    Fueltrajectory_x2.append(RWY_exit[j])
    Fueltrajectory_y2.append(RWY_exit[j + 1])
    j = j + 3

# segundo tramo (THR29-C1-2)
initial_point = {'id': 'C1'}
subinitial = {'id': '1'}
i = 1
j = 2
encontrado = False
while (corner2[i] != 0 and not encontrado):
    while corner2[i] != initial_point:
        if corner2[i] != initial_point:
            i = i + 1
    if corner2[i] == initial_point:
        encontrado = True
        j = i + 2
while (type(corner2[i]) == dict and type(corner2[j]) == float):
    Fueltrajectory_x2.append(corner2[j])
    Fueltrajectory_y2.append(corner2[j + 1])
    j = j + 3
print(Fueltrajectory_x2)
print(Fueltrajectory_y2)
# tercer tramo (C1-2 - TB3)
initial_point = {'id': 'T'}
subinitial = {'id': 'TB1'}
final_point = {'id': 'T'}
subfinal = {'id': 'TB3'}
i = 0
j = 2
k = 0
l = 1
encontrado = False
while (TW[i] != 0 and not encontrado):
    while TW[i] != initial_point:
        if TW[i] != initial_point:
            i = i + 1
    if TW[i] == initial_point:
        if TW[l] == subinitial:
            encontrado = True
            j = i + 2
            k = i + 1
        else:
            l = l + 3
j = l + 1
while (type(TW[i]) == dict and type(TW[j]) == float and TW[k] != subfinal):
    Fueltrajectory_x2.append(TW[j])
    Fueltrajectory_y2.append(TW[j + 1])
    j = j + 3
    k = k + 3

print(Fueltrajectory_x2)
print(Fueltrajectory_y2)
i = 0

t = []
vx = 0
Fueltrajectory_x_final2 = []
Fueltrajectory_y_final2 = []

distance22 = compute_distance(Fueltrajectory_x2, Fueltrajectory_y2)
# convertim en distancia (km)

i = 0
j = 1
val = 0
# Punts de trajectoria
val2 = 0
while (i < len(Fueltrajectory_y2)):
    if (j < len(Fueltrajectory_y2)):
        if (distance22[i] >= 0.08):
            val = (Fueltrajectory_y2[j] - Fueltrajectory_y2[i]) / 4
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i])
           # radius.append(distance22[i])
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i] + val)
            #radius.append(distance22[i])
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i] + 2 * val)
            #radius.append(distance22[i])
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i] + 3 * val)
            #if i + 1 < len(distance22):
             #   radius.append(distance22[i + 1])
            #else:
             #   radius.append(distance22[i])
            val2 = (Fueltrajectory_x2[j] - Fueltrajectory_x2[i]) / 4
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i])
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i] + val2)
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i] + 2 * val2)
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i] + 3 * val2)
        if (distance22[i] >= 0.05 and distance22[i] < 0.08):
            val = (Fueltrajectory_y2[j] - Fueltrajectory_y2[i]) / 2
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i])
           # radius.append(distance22[i])
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i] + val)
            #if i + 1 < len(distance22):
            #    radius.append(distance22[i + 1])
            #else:
             #   radius.append(distance22[i])
            val2 = (Fueltrajectory_x2[j] - Fueltrajectory_x2[i]) / 2
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i])
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i] + val2)
        if (distance22[i] < 0.05):
            Fueltrajectory_y_final2.append(Fueltrajectory_y2[i])
            #if i + 1 < len(distance22):
              #  radius.append(distance22[i + 1])
            #else:
               # radius.append(distance22[i])
            Fueltrajectory_x_final2.append(Fueltrajectory_x2[i])
    else:
        Fueltrajectory_y_final2.append(Fueltrajectory_y2[i])
        #radius.append(distance22[i-1])
        Fueltrajectory_x_final2.append(Fueltrajectory_x2[i])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1

# print (Fueltrajectory_y_final)
# print (Fueltrajectory_x_final)
# Time as a function of distance
i = 0
while (i + 1) < len(Fueltrajectory_x_final2):
    if Fueltrajectory_x_final2[i] == Fueltrajectory_x_final2[i + 1] and Fueltrajectory_y_final2[i] == \
            Fueltrajectory_y_final2[i + 1]:
        Fueltrajectory_x_final2.pop(i)
        Fueltrajectory_y_final2.pop(i)
    i = i + 1

TWYvelocity = 75
t=compute_distance_time(Fueltrajectory_x_final2, Fueltrajectory_y_final2, TWYvelocity)
distance3=t[0]
time2=t[1]

#time 1&2:
h=time_track(time,time2,Fueltrajectory_x_final,Fueltrajectory_y_final,Fueltrajectory_x_final2,Fueltrajectory_y_final2)
timefinal1=h[0]
x11=h[1]
y11=h[2]
x22=h[3]
y22=h[4]
trajectory3_x=[]
trajectory3_y=[]
trajectory3_x.append(RWY_exit[2])
trajectory3_y.append(RWY_exit[3])
initial_point={'id': 'RETD'}
subinitial = {'id': '1'}
final_point = {'id': 'RETD'}
subfinal = {'id': '4'}

i = 0
j = 1
encontrado = False
# initial trajectory
while (RWY_exit[i] != 0 and not encontrado):
    while RWY_exit[i] != initial_point:
        if RWY_exit[i] != initial_point:
            i = i + 1
    if RWY_exit[i] == initial_point:
        encontrado = True
        j = i + 2
while (type(RWY_exit[i]) == dict and type(RWY_exit[j]) == float):
    trajectory3_x.append(RWY_exit[j])
    trajectory3_y.append(RWY_exit[j + 1])
    j = j + 3
i = 0

t = []
vx = 0
trajectory3_xfinal = []
trajectory3_yfinal = []
medium_airplane_velocity= 80
distance3 = compute_distance(trajectory3_x,trajectory3_y)
i = 0
j = 1
val = 0
# Punts de trajectoria
val2 = 0
while (i < len(trajectory3_x)):
    if (j < len(trajectory3_y)):
        if (distance3[i] >= 0.3):
            val = (trajectory3_y[j] - trajectory3_y[i]) / 6
            trajectory3_yfinal.append(trajectory3_y[i])
            trajectory3_yfinal.append(trajectory3_y[i] + val)
            trajectory3_yfinal.append(trajectory3_y[i] + 2 * val)
            trajectory3_yfinal.append(trajectory3_y[i] + 3 * val)
            trajectory3_yfinal.append(trajectory3_y[i] + 4 * val)
            trajectory3_yfinal.append(trajectory3_y[i] + 5 * val)
            val2 = (trajectory3_x[j] - trajectory3_x[i]) / 6
            trajectory3_xfinal.append(trajectory3_x[i])
            trajectory3_xfinal.append(trajectory3_x[i] + val2)
            trajectory3_xfinal.append(trajectory3_x[i] + 2 * val2)
            trajectory3_xfinal.append(trajectory3_x[i] + 3 * val2)
            trajectory3_xfinal.append(trajectory3_x[i] + 4 * val2)
            trajectory3_xfinal.append(trajectory3_x[i] + 5 * val2)
        if (distance3[i] >= 0.05 and distance3[i] < 0.3):
            val = (trajectory3_y[j] - trajectory3_y[i]) / 2
            trajectory3_yfinal.append(trajectory3_y[i])
           # radius.append(distance22[i])
            trajectory3_yfinal.append(trajectory3_y[i] + val)

            val2 = (trajectory3_x[j] - trajectory3_x[i]) / 2
            trajectory3_xfinal.append(trajectory3_x[i])
            trajectory3_xfinal.append(trajectory3_x[i] + val2)
        if (distance3[i] < 0.05):
            trajectory3_yfinal.append(trajectory3_y[i])
            trajectory3_xfinal.append(trajectory3_x[i])
    else:
        trajectory3_yfinal.append(trajectory3_y[i])
        #radius.append(distance22[i-1])
        trajectory3_xfinal.append(trajectory3_x[i])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1
time3=[]
p=compute_distance_time(trajectory3_xfinal,trajectory3_yfinal, medium_airplane_velocity)
distance33=p[0]
time3=p[1]
#primer tramo TA-TAE
initial_point = {'id': 'T'}
subinitial = {'id': 'TA'}
final_point = {'id': 'T'}
subfinal = {'id': 'TAE'}
i = 0
j = 2
k = 0
l = 1
encontrado = False
trajectory4_x=[]
trajectory4_y=[]
while (TW[i] != 0 and not encontrado):
    while TW[i] != initial_point:
        if TW[i] != initial_point:
            i = i + 1
    if TW[i] == initial_point:
        if TW[l] == subinitial:
            encontrado = True
            j = i + 2
            k = i + 1
        else:
            l = l + 3
j = l + 1
m=j
while (type(TW[i]) == dict and type(TW[j]) == float and TW[m] != subfinal):
    trajectory4_x.append(TW[j])
    trajectory4_y.append(TW[j + 1])
    m=m+2
    j = j + 3
    k = k + 3
trajectory4_x.append(TW[j])
trajectory4_y.append(TW[j+1])

initial_point = {'id': 'T'}
subinitial = {'id': 'TE'}

i = 0
j = 2
k = 0
l = 1
encontrado = False

while (TW[i] != 0 and not encontrado):
    while TW[i] != initial_point:
        if TW[i] != initial_point:
            i = i + 1
    if TW[i] == initial_point:
        if TW[l] == subinitial:
            encontrado = True
            trajectory4_x.append(TW[l+1])
            trajectory4_y.append(TW[l+2])
        else:
            l = l + 3
initial_point = {'id': 'C2'}
subinitial = {'id': '1'}
final_point = {'id': 'C2'}
subfinal = {'id': '3'}
i = 0
j = 1

encontrado = False
while (corner2[i] != 0 and not encontrado):
    while corner2[i] != initial_point:
        if corner2[i] != initial_point:
            i = i + 1
    if corner2[i] == initial_point:
        encontrado = True
        j = i + 2
while (type(corner2[i]) == dict and type(corner2[j]) == float):
    trajectory4_x.append(corner2[j])
    trajectory4_y.append(corner2[j + 1])
    j = j + 3


distance4= compute_distance(trajectory4_x, trajectory4_y)
i = 0
j = 1
val = 0

# Punts de trajectoria
val2 = 0
trajectory4_xfinal=[]
trajectory4_yfinal=[]
velocity4=50
while (i < len(trajectory4_x)):
    if (j < len(trajectory4_y)):
        if (distance4[i] >= 0.3):
            val = (trajectory4_y[j] - trajectory4_y[i]) / 6
            trajectory4_yfinal.append(trajectory4_y[i])
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i] + val)
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i] + 2 * val)
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i] + 3 * val)
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i] + 4 * val)
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i] + 5 * val)
            Radius2.append(distance4[i])
            val2 = (trajectory4_x[j] - trajectory4_x[i]) / 6
            trajectory4_xfinal.append(trajectory4_x[i])
            trajectory4_xfinal.append(trajectory4_x[i] + val2)
            trajectory4_xfinal.append(trajectory4_x[i] + 2 * val2)
            trajectory4_xfinal.append(trajectory4_x[i] + 3 * val2)
            trajectory4_xfinal.append(trajectory4_x[i] + 4 * val2)
            trajectory4_xfinal.append(trajectory4_x[i] + 5 * val2)
        if (distance4[i] >= 0.05 and distance4[i] < 0.3):
            val = (trajectory4_y[j] - trajectory4_y[i]) / 2
            Radius2.append(distance4[i])
            trajectory4_yfinal.append(trajectory4_y[i])
            Radius2.append(distance4[i])
           # radius.append(distance22[i])
            trajectory4_yfinal.append(trajectory4_y[i] + val)

            val2 = (trajectory4_x[j] - trajectory4_x[i]) / 2
            trajectory4_xfinal.append(trajectory4_x[i])
            trajectory4_xfinal.append(trajectory4_x[i] + val2)
        if (distance4[i] < 0.05):
            trajectory4_yfinal.append(trajectory4_y[i])
            Radius2.append(distance4[i])
            trajectory4_xfinal.append(trajectory4_x[i])
    else:
        trajectory4_yfinal.append(trajectory4_y[i])
        Radius2.append(distance4[i-1])
        #radius.append(distance22[i-1])
        trajectory4_xfinal.append(trajectory4_x[i])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1

time4=[]
o=compute_distance_time(trajectory4_xfinal, trajectory4_yfinal, velocity4)
time4=o[1]
p=time_track(time3,time4,trajectory3_xfinal,trajectory3_yfinal,trajectory4_xfinal,trajectory4_yfinal)
timefinal2=p[0]
x3=p[1]
y3=p[2]
x4=p[3]
y4=p[4]
i=0
j=0
Radius2i=[]
while i<len(x3):
    if x4[i]==trajectory4_xfinal[j]:
        Radius2i.append(Radius2[j]+0.1)
        j=j+1
        i=i+1
    else:
        Radius2i.append(Radius2[j]+0.1)
        i=i+1
initial_point = {'id': 'PQ'}
subinitial = {'id': '1'}
final_point = {'id': 'PQ'}
subfinal = {'id': '5'}
trajectory5_x=[]
trajectory5_y=[]
i = 0
j = 1
encontrado = False
# initial trajectory
while (SR[i] != 0 and not encontrado):
    while SR[i] != initial_point:
        if SR[i] != initial_point:
            i = i + 1
    if SR[i] == initial_point:
        encontrado = True
        j = i + 2
while (j<len(SR)):
    if ((type(SR[i]) == dict and type(SR[j]) == float)):
        trajectory5_x.append(SR[j])
        trajectory5_y.append(SR[j + 1])
        j = j + 3

distance5= compute_distance(trajectory5_x, trajectory5_y)
i = 0
j = 1
val = 0
# Punts de trajectoria
val2 = 0
trajectory5_xfinal=[]
trajectory5_yfinal=[]
velocity5=50
while (i < len(trajectory5_x)):
    if (j < len(trajectory5_y)):
        if (distance5[i] >= 0.3):
            val = (trajectory5_y[j] - trajectory5_y[i]) / 6
            trajectory5_yfinal.append(trajectory5_y[i])
            trajectory5_yfinal.append(trajectory5_y[i] + val)
            trajectory5_yfinal.append(trajectory5_y[i] + 2 * val)
            trajectory5_yfinal.append(trajectory5_y[i] + 3 * val)
            trajectory5_yfinal.append(trajectory5_y[i] + 4 * val)
            trajectory5_yfinal.append(trajectory5_y[i] + 5 * val)
            val2 = (trajectory5_x[j] - trajectory5_x[i]) / 6
            trajectory5_xfinal.append(trajectory5_x[i])
            trajectory5_xfinal.append(trajectory5_x[i] + val2)
            trajectory5_xfinal.append(trajectory5_x[i] + 2 * val2)
            trajectory5_xfinal.append(trajectory5_x[i] + 3 * val2)
            trajectory5_xfinal.append(trajectory5_x[i] + 4 * val2)
            trajectory5_xfinal.append(trajectory5_x[i] + 5 * val2)
        if (distance5[i] >= 0.05 and distance5[i] < 0.3):
            val = (trajectory5_y[j] - trajectory5_y[i]) / 2
            trajectory5_yfinal.append(trajectory5_y[i])
           # radius.append(distance22[i])
            trajectory5_yfinal.append(trajectory5_y[i] + val)

            val2 = (trajectory5_x[j] - trajectory5_x[i]) / 2
            trajectory5_xfinal.append(trajectory5_x[i])
            trajectory5_xfinal.append(trajectory5_x[i] + val2)
        if (distance5[i] < 0.05):
            trajectory5_yfinal.append(trajectory5_y[i])
            trajectory5_xfinal.append(trajectory5_x[i])
    else:
        trajectory5_yfinal.append(trajectory5_y[i])
        #radius.append(distance22[i-1])
        trajectory5_xfinal.append(trajectory5_x[i])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1
time5=[]
b=compute_distance_time(trajectory5_xfinal, trajectory5_yfinal, velocity5)
time5=b[1]
#Primer tramo trayectoria 6 THR29-1 - TB-4
initial_point = {'id': 'THR29'}
subinitial = {'id': '1'}
final_point = {'id': 'TB'}
subfinal = {'id': '4'}
trajectory6_x=[]
trajectory6_y=[]
i = 0
j = 2
k = 0
l = 1
encontrado = False
while (RWY_exit[i] != 0 and not encontrado):
    while RWY_exit[i] != initial_point:
        if RWY_exit[i] != initial_point:
            i = i + 1
    if RWY_exit[i] == initial_point:
        l=i+1
        if RWY_exit[l] == subinitial:
            encontrado = True
            j = i + 2
            k = i + 1
        else:
            l = l + 3
j = l + 1
m=j
trajectory6_x.append(RWY_exit[j])
trajectory6_y.append (RWY_exit[j+1])

trajectory6_x.append(43.561317)
trajectory6_y.append(-6.025244)

initial_point = {'id': 'EC'}
subinitial = {'id': '1'}
i = 0
j = 2
k = 0
l = 1
encontrado = False
while (RWY_exit[i] != 0 and not encontrado):
    while RWY_exit[i] != initial_point:
        if RWY_exit[i] != initial_point:
            i = i + 1
    if RWY_exit[i] == initial_point:
        l=i+1
        while not encontrado:
            if RWY_exit[l] == subinitial:
                encontrado = True
                j = i + 2
                k = i + 1
            else:
                l = l + 3
j = l + 1
m=j
trajectory6_x.append(RWY_exit[j])
trajectory6_y.append(RWY_exit[j+1])
trajectory6_x.append(43.563611)
trajectory6_y.append(-6.034722)
trajectory6_x.append(43.565017)
trajectory6_y.append (-6.040892)

distance6= compute_distance(trajectory6_x, trajectory6_y)
i = 0
j = 1
val = 0
# Punts de trajectoria
val2 = 0
trajectory6_xfinal=[]
trajectory6_yfinal=[]
velocity6=80
while (i < len(trajectory6_x)):
    if (j < len(trajectory6_y)):
        if (distance6[i] >= 0.3):
            val = (trajectory6_y[j] - trajectory6_y[i]) / 5
            trajectory6_yfinal.append(trajectory6_y[i])
            Radius3.append(distance6[i])
            trajectory6_yfinal.append(trajectory6_y[i] + val)
            Radius3.append(distance6[i])
            trajectory6_yfinal.append(trajectory6_y[i] + 2 * val)
            Radius3.append(distance6[i])
            trajectory6_yfinal.append(trajectory6_y[i] + 3 * val)
            Radius3.append(distance6[i])
            trajectory6_yfinal.append(trajectory6_y[i] + 4 * val)
            Radius3.append(distance6[i])
            val2 = (trajectory6_x[j] - trajectory6_x[i]) / 5
            trajectory6_xfinal.append(trajectory6_x[i])
            trajectory6_xfinal.append(trajectory6_x[i] + val2)
            trajectory6_xfinal.append(trajectory6_x[i] + 2 * val2)
            trajectory6_xfinal.append(trajectory6_x[i] + 3 * val2)
            trajectory6_xfinal.append(trajectory6_x[i] + 4 * val2)
        if (distance6[i] >= 0.05 and distance6[i] < 0.3):
            val = (trajectory6_y[j] - trajectory6_y[i]) / 2
            Radius3.append(distance6[i])
            trajectory6_yfinal.append(trajectory6_y[i])
           # radius.append(distance22[i])
            trajectory6_yfinal.append(trajectory6_y[i] + val)
            Radius3.append(distance6[i])

            val2 = (trajectory6_x[j] - trajectory6_x[i]) / 2
            trajectory6_xfinal.append(trajectory6_x[i])
            trajectory6_xfinal.append(trajectory6_x[i] + val2)
        if (distance6[i] < 0.05):
            trajectory6_yfinal.append(trajectory6_y[i])
            Radius3.append(distance6[i])
            trajectory6_xfinal.append(trajectory6_x[i])
    else:
        trajectory6_yfinal.append(trajectory6_y[i])
        #radius.append(distance22[i-1])
        trajectory6_xfinal.append(trajectory6_x[i])
        Radius3.append(distance6[i-1])
    i = i + 1
    val = 0
    val2 = 0
    j = j + 1
time6=[]
q=compute_distance_time(trajectory6_xfinal, trajectory6_yfinal, velocity6)
time6=q[1]
y=time_track(time5,time6,trajectory5_xfinal,trajectory5_yfinal,trajectory6_xfinal,trajectory6_yfinal)
timefinal3=y[0]
x5=y[1]
y5=y[2]
x6=y[3]
y6=y[4]
radius3i=[]
i=0
j=0
while i<len(x6):
    if x6[i]==trajectory6_xfinal[j]:
        radius3i.append(Radius3[j]+0.2)
        j=j+1
        i=i+1
    else:
        radius3i.append(Radius3[j]+0.2)
        i=i+1
timegraph1=[]
track1x=[]
track2x=[]
ñ=time_track(time, time2, Fueltrajectory_x_final, Fueltrajectory_y_final, Fueltrajectory_x_final2, Fueltrajectory_y_final2)
timegraph1=ñ[0]
track1x=ñ[1]
track1y=ñ[2]
track2x=ñ[3]
track2y=ñ[4]


conflictpositions1x=[]
conflictpositions1y=[]
conflictpositions2x=[]
conflictpositions2y=[]
conflictpositions1xext=[]
conflictpositions1yext=[]
conflictpositions2xext=[]
conflictpositions2yext=[]

i=0
for i in range(len(track1x)):
    center_point = [{'lat': track1y[i], 'lng': track1x[i]}]
    test_point = [{'lat': track2y[i], 'lng': track2x[i]}]

    lat1 = center_point[0]['lat']
    lon1 = center_point[0]['lng']
    lat2 = test_point[0]['lat']
    lon2 = test_point[0]['lng']

    radius = Radius1# in kilometer
    radiusext=Radius1*2

    a = haversine(lon1, lat1, lon2, lat2)

    print('Distance (km) : ', a)
    if a <= radius:
        print('Inside the area')
        print('Vehicle 1: ', track1y[i],track1x[i])
        conflictpositions1x.append(track1y[i])
        conflictpositions1y.append(track1x[i])
        conflictpositions2x.append(track2y[i])
        conflictpositions2y.append(track2x[i])
        print('Vehicle 2: ', track2y[i], track2x[i])
    else:
        print('Outside the area')
    if a <= radiusext:
        conflictpositions1xext.append(track1y[i])
        conflictpositions1yext.append(track1x[i])
        conflictpositions2xext.append(track2y[i])
        conflictpositions2yext.append(track2x[i])


#x1, y1 = proj.transform(proj.Proj(init='epsg:4326'), proj.Proj(init='epsg:27700'), tracky1[0], trackx1[0])
priority1=priority(typevehicle1)
priority2=priority(typevehicle2)
priority3=priority(typevehicle3)
priority4=priority(typevehicle4)
priority5=priority(typevehicle5)
priority6=priority(typevehicle6)
v=stopvehicle(track1y,track1x,track2y,track2x,timegraph1, Radius1, conflictpositions1x, conflictpositions1y, conflictpositions2x, conflictpositions2y, priority, priority2)
x1solved=v[0]
x2solved=v[1]
y1solved=v[2]
y2solved=v[3]
timeA=v[4]
timeB=v[5]
timegraphic=v[6]
circlex=v[7]
circley=v[8]
xA=v[9]
yA=v[10]
xB=v[11]
yB=v[12]


i=1
j=0
k=1
timeAf=[]
timeBf=[]
timeAf.append(1)
timeBf.append(1)




i=1
j=0
k=1
while (i+1)<len(timeB):
    y=(timeB[i+1]-timeB[i])
    timeBf.append(timeBf[-1]+y)
    i=i+1
    k=k+1

timegraphic1=[]
timegraphic1.append(1)
i=0
while (i+1)<len(timegraphic):
    y=(timegraphic[i+1]-timegraphic[i])
    timegraphic1.append(y)
    i=i+1

a=computetime(timeAf, timeBf, xA, yA, xB, yB)
#i=0
#for i in range(len(time2)):
t=a[0]
timegraphic1.pop(-1)
timegraphic1.extend(t)
timegraphic1.append(1)
timegraphic1.append(1)

i=0
conflictpositions3x=[]
conflictpositions3y=[]
conflictpositions4x=[]
conflictpositions4y=[]
conflictpositions3xext=[]
conflictpositions3yext=[]
conflictpositions4xext=[]
conflictpositions4yext=[]
for i in range(len(y3)):
    center_point = [{'lat': y3[i], 'lng': x3[i]}]
    test_point = [{'lat': y4[i], 'lng': x4[i]}]

    lat1 = center_point[0]['lat']
    lon1 = center_point[0]['lng']
    lat2 = test_point[0]['lat']
    lon2 = test_point[0]['lng']

    radius = Radius2i[i]# in kilometer
    radiusext=Radius2i[i]*2
    a = haversine(lon1, lat1, lon2, lat2)

    print('Distance (km) : ', a)
    if a <= radius:
        print('Inside the area')
        print('Vehicle 1: ', y3[i], x3[i])
        conflictpositions3x.append(y3[i])
        conflictpositions3y.append(x3[i])
        conflictpositions4x.append(y4[i])
        conflictpositions4y.append(x4[i])
        print('Vehicle 2: ', x4[i], y4[i])
    else:
        print('Outside the area')
    if a <= radiusext:
        conflictpositions3xext.append(y3[i])
        conflictpositions3yext.append(x3[i])
        conflictpositions4xext.append(y4[i])
        conflictpositions4yext.append(x4[i])

v=stopvehicleradius(y3,x3,y4,x4,timefinal2, Radius2i, conflictpositions3x, conflictpositions3y, conflictpositions4x, conflictpositions4y, priority3, priority4)
x4solved=v[0]
x3solved=v[1]
y4solved=v[2]
y3solved=v[3]
timeC=v[4]
timeD=v[5]
timegraphic2=v[6]
circlex2=v[7]
circley2=v[8]
radius22=v[13]

xA2=v[9]
yA2=v[10]
xB2=v[11]
yB2=v[12]


i=1
j=0
k=1
timeAf2=[]
timeBf2=[]
timeAf2.append(1)
timeBf2.append(1)
while (i+1)<len(timeC):
   x=(timeC[i+1]-timeC[i])
   timeAf2.append(timeAf2[-1]+x)
   i=i+1


i=1
j=0
k=1
while (i+1)<len(timeD):
    y=(timeD[i+1]-timeD[i])
    timeBf2.append(timeBf2[-1]+y)
    i=i+1
    k=k+1

timegraphic22=[]
timegraphic22.append(1)
i=0
while (i+1)<len(timegraphic2):
    y=(timegraphic2[i+1]-timegraphic2[i])
    timegraphic22.append(y)
    i=i+1

a=computetime(timeAf2, timeBf2, xA2, yA2, xB2, yB2)
#i=0
#for i in range(len(time2)):
t2=a[0]
timegraphic22.extend(t2)
timegraphic22.append(1)
timegraphic22.append(1)
#El radio variará en función de la distancia a la intersección.

i=0
conflictpositions5x=[]
conflictpositions5y=[]
conflictpositions6x=[]
conflictpositions6y=[]
conflictpositions5xext=[]
conflictpositions5yext=[]
conflictpositions6xext=[]
conflictpositions6yext=[]
#Radius3=radiusdefine(distance5,y5,x5,y6,x6)
for i in range(len(y5)):
    center_point = [{'lat': y5[i], 'lng': x5[i]}]
    test_point = [{'lat': y6[i], 'lng': x6[i]}]

    lat1 = center_point[0]['lat']
    lon1 = center_point[0]['lng']
    lat2 = test_point[0]['lat']
    lon2 = test_point[0]['lng']

    radius = radius3i[i]# in kilometer
    radiusext=radius3i[i]*2

    a = haversine(lon1, lat1, lon2, lat2)

    print('Distance (km) : ', a)
    if a <= radius:
        print('Inside the area')
        print('Vehicle 1: ', y5[i], x5[i])
        conflictpositions5x.append(y5[i])
        conflictpositions5y.append(x5[i])
        conflictpositions6x.append(y6[i])
        conflictpositions6y.append(x6[i])
        print('Vehicle 2: ', y6[i], x6[i])
    else:
        print('Outside the area')
    if a <= radiusext:
        print('Inside the area')
        print('Vehicle 1: ', y5[i], x5[i])
        conflictpositions5xext.append(y5[i])
        conflictpositions5yext.append(x5[i])
        conflictpositions6xext.append(y6[i])
        conflictpositions6yext.append(x6[i])
        print('Vehicle 2: ', y6[i], x6[i])

v=stopvehicleradius(y5,x5,y6,x6,timefinal3, radius3i, conflictpositions5x, conflictpositions5y, conflictpositions6x, conflictpositions6y, priority5, priority6)
x5solved=v[0]
x6solved=v[1]
y5solved=v[2]
y6solved=v[3]
timeE=v[4]
timeF=v[5]
timegraphic3=v[6]
circlex3=v[7]
circley3=v[8]
xA3=v[9]
yA3=v[10]
xB3=v[11]
yB3=v[12]
radius33=v[13]


i=0
j=0
k=1
timeAf3=[]
timeBf3=[]
timeAf3.append(1)
timeBf3.append(1)
while (i+1)<len(timeE):
    y=(timeE[i+1]-timeE[i])
    timeAf3.append(timeAf3[-1]+y)
    i=i+1
    k=k+1


i=0
j=0
k=1


timegraphic23=[]
timegraphic23.append(1)
i=0
while (i+1)<len(timegraphic3):
    y=(timegraphic3[i+1]-timegraphic3[i])
    timegraphic23.append(y)
    i=i+1

#i=0
#for i in range(len(time2)):
timegraphic23.extend(timeAf3)

i=0
j=0
k=1
timegraphic11=[]
timegraphic11.append(1)
while (i+1)<len(timegraphic23):
    y=timegraphic23[i+1]
    timegraphic11.append(timegraphic11[-1]+y)
    i=i+1
    k=k+1

i=0
j=0
k=1
timegraphic222=[]
timegraphic222.append(1)
while (i+1)<len(timegraphic1):
    y=timegraphic1[i+1]
    timegraphic222.append(timegraphic222[-1]+y)
    i=i+1
    k=k+1

i=0
j=0
k=1
timegraphic33=[]
timegraphic33.append(1)
while (i+1)<len(timegraphic22):
    y=timegraphic22[i+1]
    timegraphic33.append(timegraphic33[-1]+y)
    i=i+1
    k=k+1

#stopvehicle(tracky1,trackx1,tracky2,trackx2)
u=time_graphfinal(timegraphic222,x1solved,y1solved,x2solved,y2solved,timegraphic33,x3solved,y3solved,x4solved,y4solved,timegraphic11,x5solved,y5solved,x6solved,y6solved)
timeg=u[0]
xx=u[1]
yy=u[2]
xx2=u[3]
yy2=u[4]
xx3=u[5]
yy3=u[6]
xx4=u[7]
yy4=u[8]
xx5=u[9]
yy5=u[10]
xx6=u[11]
yy6=u[12]
j=0
k=0
l=0
m=0
h=0
o=0
i = 0
j = 0
Radius2f=[]
while i < len(xx4) and j < len(radius22):
    if xx4[i] == x4solved[j] and yy4[i] == y4solved[j]:
        Radius2f.append(radius22[j])
        j = j + 1
        i = i + 1
    else:
        Radius2f.append(radius22[j])
        i = i + 1

while i<len(xx4) and j > len(x4solved):
    Radius2f.append(radius22[-1])
    i=i+1
Radius3f=[]
i=0
j=0
while i < len(xx4) and j < len(radius33):
    if xx6[i] == x6solved[j] and yy6[i] == y6solved[j]:
        Radius3f.append(radius33[j])
        j = j + 1
        i = i + 1
    else:
        Radius3f.append(radius33[j])
        i = i + 1

while i<len(xx6) and j > len(x6solved):
    Radius3f.append(radius33[-1])
    i=i+1
encontrado = False
encontradoext=False
encontrado2 = False
encontrado2ext=False
encontrado3 = False
encontrado3ext=False

for i in range(len(timeg)):
    BBox = (-6.0512, -6.0184,
            43.557939, 43.5689)
    ruh_m = plt.imread('prueba3.png')
    fig, ax = plt.subplots(figsize=(20, 8))
    ax.set_xlim(BBox[0], BBox[1])
    ax.set_ylim(BBox[2], BBox[3])
    ax.imshow(ruh_m, zorder=0, extent=BBox, aspect='auto', interpolation='nearest')
    ax.axis('off')
    fig.tight_layout()


#RADIO/111,1 (equivalencia)
#REVUSAR CIRCULO if x2solved[i] == circlex[j] and y2solved[i] == circley[j]:

    if xx2[i]==conflictpositions2x[0] and yy2[i]==conflictpositions2y[0]:
        encontrado=True
    if xx2[i] == conflictpositions2xext[0] and yy2[i] == conflictpositions2yext[0]:
        encontradoext = True
    if xx2[i]==conflictpositions2x[-1]:
        encontrado=False
    if xx2[i]==conflictpositions2xext[-1]:
        encontradoext=False
    if encontrado==True and encontradoext==True:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1/111.1, color='r', fill=True, alpha=0.8))
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1*2 / 111.1, color='y', fill=True, alpha=0.4))

    if encontradoext==True and encontrado==False:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1/111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1*2 / 111.1, color='y', fill=True, alpha=0.4))

    if encontradoext==False and encontrado==False:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1/111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx2[i], yy2[i]), Radius1*2 / 111.1, color='b', fill=True, alpha=0.2))

    if xx3[i]==circlex2[0] and yy3[i]==circley2[0]:
        encontrado2=True
    if xx4[i] == conflictpositions3xext[0] and yy4[i] == conflictpositions3yext[0]:
        encontrado2ext = True
    if xx3[i]==circlex2[-1]:
        encontrado2=False
    if xx4[i] == conflictpositions3xext[-1]:
        encontrado2ext = False
    if encontrado2==True and encontrado2ext==True:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i]/111.1, color='r', fill=True, alpha=0.8))
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i]*2 / 111.1, color='y', fill=True, alpha=0.4))
    if encontrado2ext == True and encontrado2 == False:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i]/111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i]*2 / 111.1, color='y', fill=True, alpha=0.4))
    if encontrado2ext == False and encontrado2 == False:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i] / 111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx4[i], yy4[i]), Radius2f[i] * 2 / 111.1, color='b', fill=True, alpha=0.2))
    if xx6[i]==conflictpositions6x[0] and yy6[i]==conflictpositions6y[0]:
        encontrado3=True
    if xx6[i] == conflictpositions6xext[0] and yy6[i] == conflictpositions6yext[0]:
        encontrado3ext = True
    if xx6[i]==conflictpositions6x[-1]:
       encontrado3=False
    if xx6[i] == conflictpositions6xext[-1]:
        encontrado3ext = False
    if encontrado3==True and encontrado3ext==True:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i]/111.1, color='r', fill=True, alpha=0.8))
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i]*2 / 111.1, color='y', fill=True, alpha=0.4))
    if encontrado3 == False and encontrado3ext == True:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i]/111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i]*2 / 111.1, color='y', fill=True, alpha=0.4))
    if encontrado3 == False and encontrado3ext == False:
        plt.scatter(xx[i], yy[i], s=400, color= 'r')
        plt.scatter(xx2[i], yy2[i], s=400, color= 'r')
        plt.scatter(xx3[i], yy3[i], s=400, color= 'r')
        plt.scatter(xx4[i], yy4[i], s=400, color= 'r')
        plt.scatter(xx5[i], yy5[i], s=400, color= 'r')
        plt.scatter(xx6[i], yy6[i], s=400, color= 'r')
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i] / 111.1, color='g', fill=True, alpha=0.4))
        ax.add_patch(mpl.patches.Circle((xx6[i], yy6[i]), Radius3f[i] * 2 / 111.1, color='b', fill=True, alpha=0.2))
    plt.pause(timeg[i])
    #plt.pause(time[i])

    i=i+1

    #ax.add_artist(circle)
    #ax.add_artist(scatt))


    #ax.scatter(-6.043681,43.564080)
    plt.show()
